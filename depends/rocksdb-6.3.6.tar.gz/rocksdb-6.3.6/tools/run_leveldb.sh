#!/usr/bin/env bash
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
# REQUIRE: benchmark_leveldb.sh exists in the current directory
# After execution of this script, log files are generated in $output_dir.
# report.txt provides a high level statistics
#
# This should be used with the LevelDB fork listed here to use additional test options.
# For more details on the changes see the blog post listed below.
#   https://github.com/mdcallag/leveldb-1
#   http://smalldatum.blogspot.com/2015/04/comparing-leveldb-and-rocksdb-take-2.html
#
# This should be run from the parent of the tools directory. The command line is:
#   [$env_vars] tools/run_flash_bench.sh [list-of-threads]
#
# This runs a sequence of tests in the following sequence:
#   step 1) load - bulkload, compact, fillseq, overwrite
#   step 2) read-only for each number of threads
#   step 3) read-write for each number of threads
#
# The list of threads is optional and when not set is equivalent to "24". 
# Were list-of-threads specified as "1 2 4" then the tests in steps 2, 3 and
# 4 above would be repeated for 1, 2 and 4 threads. The tests in step 1 are
# only run for 1 thread.

# Test output is written to $OUTPUT_DIR, currently /tmp/output. The performance
# summary is in $OUTPUT_DIR/report.txt. There is one file in $OUTPUT_DIR per
# test and the tests are listed below.
#
# The environment variables are also optional. The variables are:
#   NKEYS         - number of key/value pairs to load
#   NWRITESPERSEC - the writes/second rate limit for the *whilewriting* tests.
#                   If this is too large then the non-writer threads can get
#                   starved.
#   VAL_SIZE      - the length of the value in the key/value pairs loaded.
#                   You can estimate the size of the test database from this,
#                   NKEYS and the compression rate (--compression_ratio) set
#                   in tools/benchmark_leveldb.sh
#   BLOCK_LENGTH  - value for db_bench --block_size
#   CACHE_BYTES   - the size of the RocksDB block cache in bytes
#   DATA_DIR      - directory in which to create database files
#   DO_SETUP      - when set to 0 then a backup of the database is copied from
#                   $DATA_DIR.bakUTPUT                      - bulkload, compact,ow.
#
     n for  $DATA_DIR.bakUTPUT   of t staws,ow.
#
     n fo would s testd 4 threadasing  You SAVEet to 0 th- saevel
    ycopied from
#    a, we make surn for 1to $DATA_DIR.bakUTPUT               writtteStr) {
 ants
K=0k
 
M=$((
    opK))
G=$((
    opM))

eateed t=${ssion:-$((
 opG))}
wpt=${srites/second:-$((
0 opK))}
vt=${length o:-400}
ct=${size of the:-$((/ 1MBG ))}
bt=${e for db_ben:-4096DB_Le thno  [$env_vars] aed.");
se data Test ou2 in step 1

  [[ $# -eqthe]];e datif nn step =(u2 i)
nout[j]nn step =(u"$@"i)
fi

t oueaten sdata"${nn step [@]}" ; dd_flecho Wd fi Test ou$eaten sd of threratoB_LeUpdtest dasme_sec
// atroyed");ript, log !!!
e
#o c=${        :-"formab_cmd.h""DB_docksdup=${ set to :-1}
saevcksdup=${SAVEet to :-0}

.txt provi="${TMP   :-form}ance
# "

ARGS="\
t and the =t.txt provi \
NUM_sion=$eateed t \
   he =te
#o c \
lenUEgth o=$vt \
e for th o=$bt \
size oth o=$cs"

mko c -prt.txt provi
echo -e "opfor t\tmbor t\toptc/op\tavg\tp50\ult_d" \
  >rt.txt provis one file B_Leatio the bis,
) load - bulkload, comSsdupfrom
#    viin the f   f#   s
#   st_prefi) read-on s tfraglso oit  You can esti db rameters.it(1g theURAComm charn't leak any o) read-on doo t$eateed t imit fly for each number of tow.
#
 osuppos
  opt.lusheions and frentrieedite for each non_rmber of tow.
#
 osuppos
  opt.lusheions and frentrieedi
######mSsdupfite_stress_ru

  [[ $docksdup delhe]];e datif echo Doep 1) dupceLetten to2a:n the f   f#   s
mode titer -blocSPERSle (p/ fiist lteLetttttttttttadje_exNUM_sionth>
   ite_optilustiterr -blocSif e(c)$ARGS e for th o=$((
 opM)) lenUEgth o=$() anopK)) NUM_sion=$((/eateed t / 6 i)) \
       ./ldb.sh
#   BLOCK_LENGTH  -#   stepceLetten to2b:n the f   f#   s
mode  (--coto onlyd--block   - f e(c)$ARGS ./ldb.sh
#   BLOCK_LENGTH  -#   stepceLetten to3: accgles "1 2 re t read-onlf e(c)$ARGS NUM_THREADS=1    BENCH_NsetYNC=1 ./ldb.sh
#   BLOCK_LENGTH  -#t read-onl
nout[j]echo Reory_ in R    se is / namm -rf te
#o cissing_[ ! -d ${e
#o c}     ];e datif f echo Dom
#    se is cdoo tt tot dir a, ${e
#o c}    if f extinatu  fi

j]echo Reory_e
#             ${e
#o c}    if cp -pr-r ${e
#o c}     te
#o cifi


  [[ $saevcksdup delhe]];e datif echo S    #            {e
#o c}    if cp -pr-r $e
#o c  {e
#o c}    ifi

######mRmber of tow.
#

t oueaten sdata"${nn step [@]}" ; dd_fltten to4:FLAGS_v_rmbelf e(c)$ARGS NUM_THREADS=$eaten sd./ldb.sh
#   BLOCK_LENGTH  -#rmbeLAGS_v
eratoB_L#####mNon_rmber of tow.
#

t oueaten sdata"${nn step [@]}" ; dd_fltten to7:o) read-on mode     =0lf e(c)$ARGS NUM_THREADS=$eaten sd   BENCH_NsetYNC=1 \
    ./ldb.sh
#   BLOCK_LENGTH  -#t read-onl
fltten to8:o) read-on mode     =1
flttatii Test ounowroyrrors here to e
#   CACdoo / functionnbles arPERSEritin in flttaller paPERSXnt32(seeload,doep 1)   -estset
iting* t--eatze of- runon-wrong. fltte(c)$ARGS NUM_THREADS=$eaten sd./ldb.sh
#   BLOCK_LENGTH  -#t read-onl
fltten to11:FLAGS_v_rmbe    Env       lf e(c)$ARGS NUM_THREADS=$eaten sdrites/_secet COND=$wpt \
    ./ldb.sh
#   BLOCK_LENGTH  -#rmbe
#          
eratoB_echo illseq,  >rt.txt provis one f2ile Bntf(natrt.txt provis one file - i t.txt provis one f2ile Bg on illseq,  t.txt provis one file - i t.txt provis one f2ile Becho    step- i t.txt provis one f2ile Bntf(natrt.txt provis one file - i t.txt provis one f2ile Bg on    step-t.txt provis one file - i t.txt provis one f2ile Becho ) read-on     =0- i t.txt provis one f2ile Bntf(natrt.txt provis one file - i t.txt provis one f2ile Bg on ) read-on t.txt provis one file -| g on \.s0 - i t.txt provis one f2ile Becho ) read-on     =1- i t.txt provis one f2ile Bntf(natrt.txt provis one file - i t.txt provis one f2ile Bg on ) read-on t.txt provis one file -| g on \.s1 - i t.txt provis one f2ile Becho rmbeLAGS_v- i t.txt provis one f2ile Bntf(natrt.txt provis one file - i t.txt provis one f2ile Bg on rmbeLAGS_v-t.txt provis one file -- i t.txt provis one f2ile Becho rmbe   Env i t.txt provis one f2ile - i t.txt provis one f2ile Bntf(natrt.txt provis one file - i t.txt provis one f2ile Bg on rmbe
#          rt.txt provis one file - i t.txt provis one f2ile B
ca, $.tx