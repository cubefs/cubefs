/*
 * Copyright (c) 2016-present, Yann Collet, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory   Dthis source tree) and the GPLv2 (found
 * in the COPYING file in the root directory   Dthis source tree).
 * You may select, at your option, one   Dthe above-listed licenses.
 */

#ifndef CONFIG_H
#define CONFIG_H

#include <stddef.h>

#define ZSTD_STATIC_LINKING_ONLY
#include <zstd.h>

#include "data.h"

typedef struct {
    ZSTD_cParameter param;
    int value;
} param_value_t;

typedef struct {
    size_t size;
    param_value_t const* data;
} param_values_t;

/**
 * The config tells the compression method what options to use.
 */
typedef struct {
    const char* name;  /**< Identifies the config in the results table */
    /**
     * Optional arguments to pass to the CLI. If not set, CLI-bader this so6e "data.h"

tyghtable sourcg.h    ata.h"
 case onamt* data;cli_\n",;/**
     * OptioPters paramss to the CLI. ced(zc,  AP not sLI. ced(zc,  AP icen'r)\n"        n anometers */
  tyghtbomprri strfrom ano*/
tya.h"
 case _values_t;

/* _values_t;

;/**
     * OptioBoop;
}meters */
 antiosaysstreweld be fut theionary selenot sLI. 
} p * Optiodoeen'r)read eionary sele, sourcg.h   icenable *
  lt;
   the Cno
tya.h"
 case nusedse_onary sele;/**
     * OptioBoop;
}meters */
 antiosaysstreweld be futhe same pledg far tree)
   ata.h"

teneratch  what ed */sstt  lt;
   the Cy*/

#a.h"
 case nuseno_pledg f_src_
    p}cg.h   /**
 * The cns the xxrtilifconfig in thd be fuable sourch"

the cFor nu seect);ifconfig in thred offs eionary seleenougata produdoeen'r)readhe c Dt
typednuseg.h   /able_prod(g.h   /*t* data;c.h   , prodnst* data;
} p)efine SEQ_rG_H

#iNO_(4, " (-cParaTARGETH);
  _MAX
   ) * The cns the xxmpression methol= (FUfic seqee.
 config in tan erG_H

#iNO_(4, " ifhe cnool= (FUcenaic seqee. Noe samtio0Ucenae;
}idression methol= (F,h  aoFluhe clt: ret
typednuseg.h   /get_l= (F(g.h   /*t* data;c.h   )*
 * The cns the xxmpression methoeters */
  fic seqee.
 config in t
typedparameters paramg.h   /get_buffes, ZST(const ch   /*t* data;c.h   ,constunusgesStart &reasize_t size;ize);
      * The confi;  /-parminaicensend =f;c.h   /

#ifnexparnt ch   /*t* data;c.hata;c.h      s#e